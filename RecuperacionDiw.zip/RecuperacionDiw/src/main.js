// src/main.js
import './scss/main.scss' 

// No necesitamos document.querySelector('#app').innerHTML... 
// porque tu HTML ya está escrito en el index.html